apt-get upgrade && apt-get update
apt-get dist-upgrade
apt-get install python
apt-get install python2
apt-get install hydra
apt-get install figlet
figlet installed
python2 Black-Dragorn.py
